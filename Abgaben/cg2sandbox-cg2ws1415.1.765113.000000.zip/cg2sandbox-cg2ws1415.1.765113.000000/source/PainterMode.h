#pragma once

enum PainterMode
{
	DEMO_MODE,
	EXERCISE_1,
	EXERCISE_2,
	EXERCISE_3
};